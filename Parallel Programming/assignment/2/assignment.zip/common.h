#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <iostream>

using namespace std;

typedef unsigned char uchar;
typedef unsigned int uint;

#define WIDTH 0
#define HEIGHT 1